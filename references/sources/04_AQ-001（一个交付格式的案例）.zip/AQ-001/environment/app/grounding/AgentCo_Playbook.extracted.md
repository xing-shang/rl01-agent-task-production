# AgentCo redlining playbook (vendor-side, first markup)

Tier 1 (must-have): cap liability on a fees-paid basis with security carve-outs; no uncapped indemnity; no responsibility for the customer's regulatory penalties beyond AgentCo's own breach; mutual indemnity. Tier 2 (strong push): disclosed subprocessors (US residency retained); subprocessor liability at the same standard as own acts; scoped periodic audit; net-30. Tier 3: a standard customer-reference right. The playbook sets posture, not exact numbers — exercise judgment. Leave the customer's reasonable, mutual protections intact.
