#!/bin/bash
# Harbor verifier entrypoint. Grades the agent's redlined /app/contract.docx and
# writes /logs/verifier/reward.txt + /logs/verifier/judgement.json.
set -uo pipefail

export PYTHONPATH="/tests/_verifier:${PYTHONPATH:-}"
mkdir -p /logs/verifier

python3 /tests/run_verifier.py
status=$?

# Fail loudly if the verifier did not emit a reward (e.g. missing rubrics / judge
# bundle); never let a broken verifier read as a trivial pass.
if [ ! -f /logs/verifier/reward.txt ]; then
    echo "VERIFIER ERROR: no reward.txt produced" >&2
    exit 1
fi

exit "$status"
