"""Inline-annotated Markdown view of a redlined docx, for the LLM judge.

Differs from `redline_engine.document.DocumentView.to_markdown` in one key way:
this serializer walks the OOXML directly and emits tracked changes and
comment anchors **inline** in CriticMarkup style:

    [p-100] (Normal) Service Commitments. Provider shall make Services
    Available to LargeCo ~~99.99%~~++99%++ {cmt-12} of the time (the
    "Uptime Commitment"); ...

This is much easier for the judge to reason about than reading the body text
(with deletions stripped) and cross-referencing an appendix.

Conventions:
- `~~text~~`            = tracked deletion (was there originally, is being removed)
- `++text++`            = tracked insertion (newly added)
- `~~old~~++new~~`      = a replacement (the natural composition of del + ins)
- `{cmt-N}`             = comment range ends here; full body in the appendix
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from docx import Document
from lxml import etree

from redline_engine.document import DocumentView, ExistingComment, ExistingRevision
from redline_engine.ooxml_utils import qn


def render_inline(redlined_path: str | Path) -> str:
    """Return a Markdown view of `redlined_path` with inline change markers.

    The output is the body (paragraphs with inline annotations) followed by
    an appendix that lists every comment's full text and threading metadata.
    """
    path = Path(redlined_path)
    view = DocumentView.load(path)
    lines: list[str] = [f"# {path.name}", ""]

    for p_info in view.paragraphs:
        runtime_p = view.runtime_paragraph(p_info.id)
        rendered = _render_paragraph(runtime_p._p)
        # Skip empty rendered text to keep the view tight, but keep paragraph
        # IDs aligned with the underlying doc (so judge can cite p-NNN exactly).
        if not rendered.strip() and not p_info.has_revisions and not p_info.has_comments:
            continue
        flags = []
        if p_info.has_revisions:
            flags.append("REVS")
        if p_info.has_comments:
            flags.append("CMTS")
        flag_str = f" {{{','.join(flags)}}}" if flags else ""
        indent = "  " * (p_info.list_level or 0)
        lines.append(f"[{p_info.id}] ({p_info.style}){flag_str} {indent}{rendered}")

    # Comment appendix — judge needs the full text of every comment referenced
    # inline by {cmt-N}. Includes threading (replies to which parent).
    if view.comments:
        lines.append("")
        lines.append("## Comment appendix")
        lines.append("")
        for c in view.comments:
            lines.append(_format_comment(c))

    # Revision appendix — fallback that lists each tracked change in full.
    # Useful when an inline `~~…~~` got truncated by a complex XML structure.
    if view.revisions:
        lines.append("")
        lines.append("## Tracked-change appendix")
        lines.append("")
        for r in view.revisions:
            lines.append(_format_revision(r))

    return "\n".join(lines)


# --- paragraph rendering --------------------------------------------------- #


def _render_paragraph(p_elem) -> str:
    """Walk a `<w:p>` element and emit inline-annotated text."""
    parts: list[str] = []
    for child in p_elem.iterchildren():
        tag = etree.QName(child).localname
        if tag == "r":
            parts.append(_runtext(child))
        elif tag == "ins":
            text = _ins_text(child)
            if text:
                parts.append(f"++{text}++")
        elif tag == "del":
            text = _del_text(child)
            if text:
                parts.append(f"~~{text}~~")
        elif tag in ("moveFrom",):
            text = _del_text(child)
            if text:
                parts.append(f"~~{text}~~ (moved-from)")
        elif tag in ("moveTo",):
            text = _ins_text(child)
            if text:
                parts.append(f"++{text}++ (moved-to)")
        elif tag == "commentRangeStart":
            # Optional: emit nothing here; we mark the end instead.
            pass
        elif tag == "commentRangeEnd":
            cid = child.get(qn("w:id"))
            if cid is not None:
                parts.append(f" {{cmt-{cid}}}")
        elif tag == "commentReference":
            # Already handled at commentRangeEnd; ignore here.
            pass
        elif tag == "smartTag":
            # smartTag wraps runs — recurse into it.
            parts.append(_render_paragraph(child))
        elif tag in ("hyperlink", "sdt", "sdtContent"):
            # Walk into hyperlinks and structured-doc tags so we don't drop text.
            parts.append(_render_paragraph(child))
        # Skip everything else (bookmarks, properties, etc.) — they don't render.
    text = "".join(parts)
    # Collapse runs of `{cmt-N} {cmt-M}` into a single space-separated cluster
    # so they're easy to scan but don't break the prose flow.
    return text


def _runtext(r_elem) -> str:
    """Extract text from a `<w:r>` (a plain run, not wrapped in ins/del)."""
    out: list[str] = []
    for t in r_elem.iter(qn("w:t")):
        out.append(t.text or "")
    return "".join(out)


def _ins_text(ins_elem) -> str:
    """Extract the inserted text from a `<w:ins>` wrapper (regular `<w:t>` inside)."""
    out: list[str] = []
    for t in ins_elem.iter(qn("w:t")):
        out.append(t.text or "")
    return "".join(out)


def _del_text(del_elem) -> str:
    """Extract the deleted text from a `<w:del>` wrapper (uses `<w:delText>`)."""
    out: list[str] = []
    for t in del_elem.iter(qn("w:delText")):
        out.append(t.text or "")
    # Some authors / tools also leave plain w:t inside w:del; include them too.
    for t in del_elem.iter(qn("w:t")):
        out.append(t.text or "")
    return "".join(out)


# --- appendix formatting --------------------------------------------------- #


def _format_comment(c: ExistingComment) -> str:
    head = f"- [cmt-{c.id}] by {c.author!r}"
    if c.parent_id is not None:
        head += f" (reply to cmt-{c.parent_id})"
    spans = ",".join(c.paragraph_ids) or "?"
    body = c.text.replace("\n", " ").strip()
    return f"{head} on [{spans}]: {body}"


def _format_revision(r: ExistingRevision) -> str:
    spans = ",".join(r.paragraph_ids) or "?"
    text = r.text.replace("\n", " ").strip()
    return f"- [rev-{r.id}] {r.type} by {r.author!r} on [{spans}]: {text!r}"
