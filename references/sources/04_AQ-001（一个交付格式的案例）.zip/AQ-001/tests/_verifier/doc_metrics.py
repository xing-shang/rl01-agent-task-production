"""Quantitative metrics about a redlined document, separate from rubric grading.

Three counts at different granularities:

- **redlines** (primary): each contiguous run of touched paragraphs counts as
  one redline. Closest to how a lawyer counts: "I made one redline to Section
  5.6" — even if that redline involved multiple word-level edits across two
  paragraphs. Use this for `excess = redlines - rubric_count`.

- **edit_operations**: each grouped `<w:del>` + `<w:ins>` pair counts as one
  operation. Closer to "how many distinct places in the OOXML the model
  touched". Useful for diagnosing whether a model made many small edits per
  redline vs few large edits.

- **total_revisions**: raw count of `<w:ins>` and `<w:del>` elements. Useful
  for diagnosing how granular the model's edits were (a model that produces
  word-by-word edits has a much higher revision count than one that produces
  clause-level rewrites, even if the redline count is the same).

For comparing to rubric criteria, **`redlines` is the right number**: each
rubric describes one logical change; each redline addresses one logical
change. `total_revisions` and `edit_operations` measure granularity, not
scope.
"""

from __future__ import annotations

from dataclasses import dataclass

from lxml import etree

from redline_engine.document import DocumentView
from redline_engine.ooxml_utils import qn


# OOXML tags that don't break adjacency between paired del/ins (replace) — we
# allow comment range markers and bookmarks to sit between the pieces.
_TRANSPARENT_TAGS = {
    "commentRangeStart",
    "commentRangeEnd",
    "commentReference",
    "bookmarkStart",
    "bookmarkEnd",
    "proofErr",
}

_REVISION_TAGS = ("ins", "del", "moveFrom", "moveTo")


@dataclass
class DocMetrics:
    """Per-document metrics used both by the report and as supplementary fields
    on `ModelScore`.
    """

    redlines: int                  # PRIMARY: clusters of contiguous touched paragraphs
    edit_operations: int           # secondary: grouped <w:del>+<w:ins> pairs (= 1 replace)
    total_revisions: int           # raw OOXML <w:ins>/<w:del>/move{From,To} count
    touched_paragraphs: int        # how many paragraphs had at least one edit
    comments_added: int            # by the filtered author (or all comments)


def collect(
    view: DocumentView,
    author_substring: str | None = None,
    *,
    max_paragraph_gap: int = 0,
) -> DocMetrics:
    """Compute metrics for `view`.

    If `author_substring` is provided, only count revisions and comments whose
    `w:author` contains it. Useful for level ≥ 2 tasks where the source doc
    already has prior turns' revisions from a different author. For level 1
    tasks (where all revisions belong to the model under test), pass None.

    `max_paragraph_gap` controls redline clustering: 0 (default) requires
    paragraphs to be strictly consecutive to count as one redline; higher
    values tolerate that many untouched paragraphs between two touched
    paragraphs in the same cluster. Use 0 unless you have a reason to
    aggregate more aggressively.
    """
    return DocMetrics(
        redlines=count_redlines(
            view, author_substring, max_gap=max_paragraph_gap
        ),
        edit_operations=count_edit_operations(view, author_substring),
        total_revisions=count_revisions(view, author_substring),
        touched_paragraphs=count_touched_paragraphs(view, author_substring),
        comments_added=count_author_comments(view, author_substring),
    )


def count_revisions(
    view: DocumentView, author_substring: str | None = None
) -> int:
    """Raw count of `<w:ins>`, `<w:del>`, `<w:moveFrom>`, `<w:moveTo>` elements."""
    n = 0
    for r in view.revisions:
        if author_substring is None or author_substring in r.author:
            n += 1
    return n


def count_redlines(
    view: DocumentView,
    author_substring: str | None = None,
    *,
    max_gap: int = 0,
) -> int:
    """Count distinct redlines = contiguous runs of touched paragraphs.

    A "redline" is a logical edit at the document level. Lawyers count:
    "I made 5 redlines" = "I made 5 logical changes," not "I made 5
    word-level OOXML modifications". A multi-word rewrite to one paragraph,
    or an edit that spans two adjacent paragraphs of the same section, is
    still ONE redline.

    Implementation: walk paragraphs in document order, find runs of touched
    paragraphs. With `max_gap=0` (default, strict), paragraphs must be
    directly consecutive to belong to the same redline. With higher values,
    that many untouched paragraphs in between are tolerated — useful when
    a single rubric-driven change skips a section heading or blank.
    """
    touched = _paragraph_touched_flags(view, author_substring)
    if not any(touched):
        return 0
    if max_gap < 0:
        max_gap = 0

    clusters = 0
    i = 0
    n = len(touched)
    while i < n:
        if not touched[i]:
            i += 1
            continue
        clusters += 1
        # Walk forward through this cluster, allowing up to `max_gap` untouched
        # paragraphs between any two touched paragraphs.
        last_touched_idx = i
        j = i + 1
        while j < n:
            if touched[j]:
                last_touched_idx = j
                j += 1
            elif j - last_touched_idx <= max_gap:
                j += 1
            else:
                break
        i = last_touched_idx + 1
    return clusters


def count_touched_paragraphs(
    view: DocumentView, author_substring: str | None = None
) -> int:
    """Count distinct paragraphs that contain ≥ 1 revision element.

    Diagnostic metric between `redlines` (cluster count) and
    `edit_operations` (per-OOXML-group count). If a model touches 50
    paragraphs in 35 clusters, the average cluster is ~1.4 paragraphs.
    """
    return sum(_paragraph_touched_flags(view, author_substring))


def _paragraph_touched_flags(
    view: DocumentView, author_substring: str | None
) -> list[bool]:
    """Bool per paragraph: has at least one matching ins/del/move element."""
    flags: list[bool] = []
    for p_info in view.paragraphs:
        p_elem = view.runtime_paragraph(p_info.id)._p
        touched = False
        for child in p_elem.iter():
            tag = etree.QName(child).localname
            if tag in _REVISION_TAGS:
                author = child.get(qn("w:author"), "") or ""
                if author_substring is None or author_substring in author:
                    touched = True
                    break
        flags.append(touched)
    return flags


def count_edit_operations(
    view: DocumentView, author_substring: str | None = None
) -> int:
    """Count distinct redline operations.

    Grouping rules:
    - A `<w:del>` immediately followed by a `<w:ins>` from the **same author**
      is a single "replace" operation (1 op).
    - A standalone `<w:del>` is 1 op (a delete).
    - A standalone `<w:ins>` is 1 op (an insertion).
    - Adjacency tolerates comment range markers / bookmarks / proofreading
      marks between the two pieces (they don't break the pair).
    - Pairs do **not** span paragraphs — operations are scoped to one `<w:p>`.

    This count is the metric users likely want when comparing to the number
    of rubric criteria, since each rubric verb (delete/replace/insert/reject)
    typically corresponds to one operation here.
    """
    ops = 0
    for p_info in view.paragraphs:
        runtime_p = view.runtime_paragraph(p_info.id)
        ops += _count_ops_in_paragraph(runtime_p._p, author_substring)
    return ops


def count_author_comments(
    view: DocumentView, author_substring: str | None = None
) -> int:
    """Count comments whose author contains `author_substring` (or all comments)."""
    n = 0
    for c in view.comments:
        if author_substring is None or author_substring in c.author:
            n += 1
    return n


def _count_ops_in_paragraph(
    p_elem, author_substring: str | None
) -> int:
    """Walk a `<w:p>`'s children and count distinct redline operations.

    State machine: track the author of the most-recent unpaired `<w:del>`.
    If we then see a `<w:ins>` by the same author (with only transparent tags
    in between), the new `<w:ins>` is consumed as the right half of a replace
    rather than being counted as a separate op.
    """
    ops = 0
    pending_del_author: str | None = None  # author of an unpaired prior <w:del>
    for child in p_elem.iterchildren():
        tag = etree.QName(child).localname
        if tag in _TRANSPARENT_TAGS:
            continue
        if tag not in _REVISION_TAGS:
            # Any other element (plain run, hyperlink, smartTag, …) breaks
            # the del-ins pairing.
            pending_del_author = None
            continue

        author = child.get(qn("w:author"), "") or ""
        if author_substring is not None and author_substring not in author:
            # Edit from a different author (e.g., counterparty in level ≥ 2).
            # Don't count it; reset pairing state.
            pending_del_author = None
            continue

        if tag == "del" or tag == "moveFrom":
            # New deletion → counts as 1 op now; may turn into a replace if a
            # matching ins follows, but the op count for the pair stays at 1.
            ops += 1
            pending_del_author = author
        elif tag == "ins" or tag == "moveTo":
            if pending_del_author == author:
                # Pair with the preceding del → don't increment.
                pending_del_author = None
            else:
                ops += 1
                pending_del_author = None
    return ops
