#!/usr/bin/env python3
"""RedlineBench verifier: grade a redlined contract against attorney rubrics.

Flow:
  1. Validity gate — the contract must load as a .docx and contain at least one
     tracked change attributed to the task's declared author. Fails → reward 0.
  2. Render the document into an inline-annotated CriticMarkup view.
  3. Send the view + rubrics to the LLM judge(s) for binary PASS/FAIL per
     rubric. By default this is a 3-judge panel (gpt-5.4-mini, claude-haiku,
     gemini-3.1-flash-lite) with rubric-level strict majority vote (≥2 of 3
     vote PASS → PASS). The panel composition is intentionally distinct from
     the four models we benchmark (gpt-5.5, opus-4.8, gemini-3.5-flash,
     claude-fable-5) so no judge grades its own family's outputs.
  4. Score: reward = earned_weight / total_weight on the (panel-majority or
     single-judge) verdicts. Rubrics the judge omits count as FAIL.
  5. Write /logs/verifier/reward.json (reward + deterministic diagnostics)
     and /logs/verifier/grade.json (full per-rubric verdicts for audit). In
     panel mode, also write /logs/verifier/judges/<judge>.json for each
     panel member's raw verdicts.

Configuration (env vars, precedence top→bottom):
  JUDGE_PANEL=<csv>   — comma-separated judge models; overrides default panel
                        (e.g. "openai/gpt-5.4-mini,anthropic/claude-haiku").
                        Use a single entry to opt into a one-judge panel.
  JUDGE_MODEL=<id>    — single-judge mode (diagnostic). Ignored if
                        JUDGE_PANEL is set.
  (neither set)       — falls back to the canonical panel below.

Standalone usage (outside Harbor, for development):
  python judge.py --contract path/to/redlined.docx [--out-dir ./out] [--dry-run]
  --dry-run renders the view and computes diagnostics without calling any judge.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import re
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from annotated_view import render_inline  # noqa: E402
from doc_metrics import collect  # noqa: E402
from judge_prompts import JUDGE_SYSTEM_PROMPT, build_user_prompt  # noqa: E402
from redline_engine.document import DocumentView  # noqa: E402

# Canonical 3-judge panel. Picked so none of the panel members share a
# family with any of the four currently-benchmarked redlining models —
# gpt-5.5 is judged by gpt-5.4-mini's older-and-smaller cousin (also
# different RLHF generation), claude-opus-4.8 + claude-fable-5 are
# judged by claude-haiku-4-5, and gemini-3.5-flash is judged by
# gemini-3.1 (one major version back). Strict-majority voting on 3
# binary verdicts has no ties.
#
# Model identifiers are litellm-style provider-prefixed strings and
# MATCH the ones the proven panel-with-fable run actually used (see
# runs/ref1-trial1/panel/judges/*/<task>.json :: judge_model). The
# Anthropic entry uses the dated alias because the generic
# `anthropic/claude-haiku` short name does not resolve to a specific
# snapshot reliably across litellm versions.
DEFAULT_JUDGE_PANEL: list[str] = [
    "openai/gpt-5.4-mini",
    "anthropic/claude-haiku-4-5-20251001",
    "gemini/gemini-3.1-flash-lite",
]

# Diagnostic single-judge default — only used if `JUDGE_MODEL` env is
# set AND `JUDGE_PANEL` is not. The default flow uses the panel above;
# this constant exists so the env-driven fallback has a deterministic
# target model.
DEFAULT_JUDGE_MODEL = "openai/gpt-5.5"

MAX_RETRIES = 10


def resolve_judges() -> tuple[list[str], str]:
    """Resolve which judges to call from the env. Returns
    `(judges, mode)` where mode is `"panel"` or `"single"`.

    Precedence:
      1. `JUDGE_PANEL` (csv) — explicit panel composition.
      2. `JUDGE_MODEL` (single id) — single-judge diagnostic mode.
      3. Default: `DEFAULT_JUDGE_PANEL` in panel mode.
    """
    panel_env = (os.environ.get("JUDGE_PANEL") or "").strip()
    if panel_env:
        judges = [j.strip() for j in panel_env.split(",") if j.strip()]
        if len(judges) % 2 == 0:
            print(
                f"WARNING: even-sized panel ({len(judges)} judges) — ties "
                "possible in majority vote (will resolve as FAIL).",
                file=sys.stderr,
            )
        return judges, "panel"
    single_env = (os.environ.get("JUDGE_MODEL") or "").strip()
    if single_env:
        return [single_env], "single"
    return list(DEFAULT_JUDGE_PANEL), "panel"


def majority_vote(per_judge_responses: list[dict]) -> dict:
    """Reduce a list of per-judge `{"verdicts": [...]}` payloads to a
    single panel response via strict majority vote per rubric.

    SHARED LOGIC, intentionally inlined here:

    The strict-majority rule (`n_pass * 2 > total → PASS`) is the
    single source of truth defined in
    `src/redlinebench/panel.py::majority_vote_per_rubric` and used by
    the post-hoc panel CLI (`panel.main()`) and the report-side reader
    (`panel_reader.collect_panel_rows`). This verifier runs inside a
    Harbor sandbox without access to the `redlinebench` package, so we
    cannot `import` from it — the rule is mirrored inline. **Keep this
    function semantically in sync with `panel.majority_vote_per_rubric`.**

    The function's INPUT shape differs from the shared helper's
    because the verifier sees raw judge responses (with justifications)
    while the helper sees the grade.json schema. We adapt to the
    response-shape here and pass through the same vote.

    Justifications can't be voted; we surface the first non-empty
    justification from the winning side so the audit trail still
    carries attorney-style rationale.
    """
    from collections import defaultdict

    # rid → {verdict → [justification, ...]}
    by_rid: dict[str, dict[str, list[str]]] = defaultdict(
        lambda: {"PASS": [], "FAIL": []}
    )
    for resp in per_judge_responses:
        for v in resp.get("verdicts", []):
            rid = v.get("rubric_id")
            if not rid:
                continue
            verdict = v.get("verdict")
            if verdict not in ("PASS", "FAIL"):
                verdict = "FAIL"
            by_rid[rid][verdict].append(v.get("justification") or "")

    out_verdicts: list[dict] = []
    for rid, votes in by_rid.items():
        n_pass = len(votes["PASS"])
        n_fail = len(votes["FAIL"])
        total = n_pass + n_fail
        # Strict-majority rule — matches
        # `panel.majority_vote_per_rubric` line-for-line.
        verdict = "PASS" if n_pass * 2 > total else "FAIL"
        bucket = votes[verdict]
        justification = next(
            (j for j in bucket if j.strip()),
            f"(panel majority: {n_pass} PASS / {n_fail} FAIL)",
        )
        out_verdicts.append({
            "rubric_id": rid,
            "verdict": verdict,
            "justification": justification,
        })
    return {"verdicts": out_verdicts}


def load_task() -> dict:
    return json.loads((Path(__file__).resolve().parent / "rubrics.json").read_text())


# --- validity gate ---------------------------------------------------------- #


def validity_gate(contract: Path, author: str) -> tuple[bool, str, "DocumentView | None"]:
    """Pass iff the docx loads and the agent left ANY authored trace —
    a tracked change OR a comment.

    Comments count because accepting the counterparty's outstanding edits by
    leaving them untouched (replying on threads) is a legitimate, sometimes
    optimal strategy on late deal-closing turns: in the original benchmark
    run, models scored 1.0 on turn-4 tasks with zero new tracked changes.
    A crashed or no-op agent leaves no authored trace at all and still gates
    to 0; everything else is the judge's call.
    """
    if not contract.exists():
        return False, f"output file not found: {contract}", None
    try:
        view = DocumentView.load(contract)
    except Exception as exc:  # noqa: BLE001
        return False, f"output is not a loadable .docx: {exc}", None
    authored_revs = [r for r in view.revisions if author in (r.author or "")]
    authored_cmts = [c for c in view.comments if author in (c.author or "")]
    if not authored_revs and not authored_cmts:
        return False, (
            f"no tracked changes or comments by author {author!r} found "
            f"({len(view.revisions)} revisions / {len(view.comments)} comments "
            "by other authors)"
        ), view
    return True, "", view


# --- judge call -------------------------------------------------------------- #


def call_judge(model: str, system: str, user: str) -> dict:
    """Call the judge with retries.

    No temperature pin: reasoning models (gpt-5.5 etc.) reject anything but
    the default. Strict output shape is requested via response_format
    json_object; if the provider rejects that, degrade once and continue.
    Deterministic client errors (4xx other than 429) fail fast instead of
    burning retries.
    """
    import litellm

    kwargs: dict = {"response_format": {"type": "json_object"}}
    last_exc: Exception | None = None
    for attempt in range(MAX_RETRIES):
        try:
            resp = litellm.completion(
                model=model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                timeout=600,
                **kwargs,
            )
            raw = resp.choices[0].message.content or ""
            return parse_judge_json(raw)
        except Exception as exc:  # noqa: BLE001
            msg = str(exc)
            if "response_format" in kwargs and "response_format" in msg:
                # provider doesn't support structured output — degrade once,
                # don't consume a retry
                kwargs.pop("response_format")
                print("judge: provider rejected response_format; retrying without it",
                      file=sys.stderr)
                continue
            status = getattr(exc, "status_code", None)
            if status is not None and 400 <= status < 500 and status != 429:
                raise RuntimeError(f"judge request invalid (no retry): {exc!r}") from exc
            last_exc = exc
            delay = min(2**attempt, 60) + random.uniform(0, 1)
            print(f"judge attempt {attempt + 1}/{MAX_RETRIES} failed: {exc!r}; "
                  f"retrying in {delay:.0f}s", file=sys.stderr)
            time.sleep(delay)
    raise RuntimeError(f"judge failed after {MAX_RETRIES} attempts: {last_exc!r}")


def parse_judge_json(raw: str) -> dict:
    """Parse the judge's JSON, tolerating markdown code fences."""
    text = raw.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fence:
        text = fence.group(1).strip()
    if not text.startswith("{"):
        brace = text.find("{")
        if brace >= 0:
            text = text[brace:]
    data = json.loads(text)
    if "verdicts" not in data or not isinstance(data["verdicts"], list):
        raise ValueError("judge response missing 'verdicts' list")
    return data


# --- scoring ----------------------------------------------------------------- #


def aggregate(verdicts: list[dict], rubrics: list[dict]) -> dict:
    """Weighted score with penalty-rubric support.

    Positive-weight rubrics are desirable edits: PASS earns the weight.
    Negative-weight rubrics are edits the attorney flagged as undesirable:
    PASS (the model did the thing) subtracts |weight|. The denominator is the
    sum of positive weights (the maximum achievable), and the final score is
    clamped to [0, 1] so penalties can't push it negative. The judge grades
    every rubric the same way ("does the document contain this edit?"); only
    aggregation interprets the sign.
    """
    by_id = {}
    for v in verdicts:
        rid = v.get("rubric_id")
        if rid and rid not in by_id:
            by_id[rid] = v
    per_rubric = []
    earned = 0
    penalty = 0
    total_positive = 0
    for r in rubrics:
        w = int(r["weight"])
        if w > 0:
            total_positive += w
        v = by_id.get(r["id"])
        verdict = (v or {}).get("verdict", "FAIL")
        if verdict not in ("PASS", "FAIL"):
            verdict = "FAIL"
        justification = (v or {}).get(
            "justification", "(judge did not address this rubric)"
        )
        if verdict == "PASS":
            if w > 0:
                earned += w
            elif w < 0:
                penalty += -w
        per_rubric.append(
            {
                "rubric_id": r["id"],
                "verdict": verdict,
                "weight": w,
                "is_penalty": w < 0,
                "category": r.get("category"),
                "criteria": r["criteria"],
                "justification": justification,
            }
        )
    raw = (earned - penalty) / total_positive if total_positive else 0.0
    return {
        "weighted": max(0.0, min(1.0, raw)),
        "weighted_unclamped": raw,
        "earned_weight": earned,
        "penalty_weight": penalty,
        "total_weight": total_positive,
        "n_pass": sum(
            1 for p in per_rubric if p["verdict"] == "PASS" and not p["is_penalty"]
        ),
        "n_total": sum(1 for p in per_rubric if not p["is_penalty"]),
        "n_penalties_triggered": sum(
            1 for p in per_rubric if p["verdict"] == "PASS" and p["is_penalty"]
        ),
        "n_penalty_rubrics": sum(1 for p in per_rubric if p["is_penalty"]),
        "per_rubric": per_rubric,
    }


def diagnostics(view: "DocumentView | None", author: str, n_rubrics: int) -> dict:
    if view is None:
        return {
            "redlines": 0, "edit_operations": 0, "total_revisions": 0,
            "touched_paragraphs": 0, "comments_added": 0,
            "excess_redlines": 0, "median_insertion_chars": 0,
        }
    m = collect(view, author_substring=author)
    ins_lengths = [
        len(r.text or "")
        for r in view.revisions
        if r.type in ("ins", "moveTo") and author in (r.author or "") and (r.text or "").strip()
    ]
    return {
        "redlines": m.redlines,
        "edit_operations": m.edit_operations,
        "total_revisions": m.total_revisions,
        "touched_paragraphs": m.touched_paragraphs,
        "comments_added": m.comments_added,
        "excess_redlines": max(0, m.redlines - n_rubrics),
        "median_insertion_chars": int(statistics.median(ins_lengths)) if ins_lengths else 0,
    }


# --- main -------------------------------------------------------------------- #


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", default="/app/contract.docx")
    parser.add_argument("--out-dir", default="/logs/verifier")
    parser.add_argument("--dry-run", action="store_true",
                        help="render + diagnostics only; no judge call, no reward written")
    args = parser.parse_args()

    task = load_task()
    author = task["author"]
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    contract = Path(args.contract)

    ok, reason, view = validity_gate(contract, author)
    diag = diagnostics(view, author, len(task["rubrics"]))

    if not ok:
        print(f"VALIDITY GATE FAILED: {reason}", file=sys.stderr)
        grade = {
            "task_id": task["task_id"], "scenario_id": task["scenario_id"],
            "side": task["side"], "level": task["level"], "author": author,
            "gate": {"passed": False, "reason": reason},
            "score": {"weighted": 0.0, "n_pass": 0, "n_total": len(task["rubrics"]),
                      **diag},
        }
        (out_dir / "grade.json").write_text(json.dumps(grade, indent=2))
        (out_dir / "reward.json").write_text(json.dumps({"reward": 0.0, **diag}, indent=2))
        return 0

    annotated = render_inline(contract)
    (out_dir / "annotated_view.md").write_text(annotated)

    if args.dry_run:
        print(json.dumps({"gate": "passed", **diag}, indent=2))
        print(f"\nannotated view: {len(annotated)} chars "
              f"-> {out_dir / 'annotated_view.md'}")
        return 0

    judges, mode = resolve_judges()
    user_prompt = build_user_prompt(task, annotated)
    print(f"judging mode: {mode}  ({len(judges)} judge(s): {', '.join(judges)})")
    print(f"rubrics: {len(task['rubrics'])}, prompt chars: {len(user_prompt)}")

    judge_errors: list[tuple[str, str]] = []
    survivors: list[str] = []
    if mode == "panel":
        per_judge: list[dict] = []
        # Save each judge's raw verdicts to /logs/verifier/judges/<judge>.json
        # for post-hoc audit (sensitivity analysis, judge-agreement
        # checks, etc.). This mirrors what redlinebench.rejudge writes
        # at the run-level — keeping the same layout at the verifier
        # level means panel.py / panel_reader.py can consume the
        # outputs directly with no schema bridge.
        judges_dir = out_dir / "judges"
        judges_dir.mkdir(parents=True, exist_ok=True)
        # Tolerate per-judge failure: if one of N judges errors after
        # exhausting `call_judge`'s retries (typically auth, quota, or
        # an unreachable provider), drop it from the vote and proceed
        # with the survivors. Failing the whole task on any one
        # judge's outage would amplify the 3-judge panel's surface
        # area 3× over single-judge mode — exactly the wrong tradeoff.
        # Only when EVERY judge fails do we raise.
        for j in judges:
            print(f"calling panel judge {j}...")
            try:
                resp = call_judge(j, JUDGE_SYSTEM_PROMPT, user_prompt)
            except Exception as exc:  # noqa: BLE001
                print(f"  judge {j} FAILED: {exc!r}", file=sys.stderr)
                judge_errors.append((j, str(exc)[:300]))
                continue
            per_judge.append(resp)
            survivors.append(j)
            sanitized = j.replace("/", "-").replace(":", "-")
            (judges_dir / f"{sanitized}.json").write_text(
                json.dumps(resp, indent=2)
            )
        if not per_judge:
            raise RuntimeError(
                f"all {len(judges)} panel judges failed; "
                f"errors: {judge_errors}"
            )
        if judge_errors:
            print(
                f"WARNING: {len(judge_errors)}/{len(judges)} panel judges "
                f"failed; proceeding with {len(survivors)} survivor(s): "
                f"{survivors}",
                file=sys.stderr,
            )
        response = majority_vote(per_judge)
    else:
        # Single-judge: just the one call, no per-judge files.
        response = call_judge(judges[0], JUDGE_SYSTEM_PROMPT, user_prompt)
        survivors = [judges[0]]

    score = aggregate(response["verdicts"], task["rubrics"])

    grade = {
        "task_id": task["task_id"], "scenario_id": task["scenario_id"],
        "side": task["side"], "level": task["level"], "author": author,
        # Carry the judge config on the grade so downstream consumers
        # can tell which method produced these verdicts. In panel mode
        # `judge_model` is a single descriptive label, `judges` is the
        # configured panel, and `survivors` is the subset that
        # actually contributed votes (drops any judge that errored
        # after retries). When everything works, survivors == judges.
        "judge_model": (
            f"panel({','.join(judges)})" if mode == "panel" else judges[0]
        ),
        "judge_mode": mode,
        "judges": judges,
        "survivors": survivors,
        "judge_errors": judge_errors,
        "gate": {"passed": True},
        "score": {**score, **diag},
    }
    (out_dir / "grade.json").write_text(json.dumps(grade, indent=2))
    (out_dir / "reward.json").write_text(
        json.dumps({"reward": round(score["weighted"], 6), **diag}, indent=2)
    )
    print(f"reward: {score['weighted']:.3f} "
          f"({score['n_pass']}/{score['n_total']} rubrics, "
          f"{score['earned_weight']}/{score['total_weight']} weight)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
