#!/usr/bin/env python3
"""Harbor verifier entrypoint (invoked by tests/test.sh).

Grades the agent's redlined /app/contract.docx against the attorney rubrics in
/tests/rubrics.json using the protected judge bundle in /tests/_verifier, and
writes the two artifacts the Harbor runner reads:

    /logs/verifier/reward.txt     -- single float 0.0-1.0 ("{reward:.4f}\n")
    /logs/verifier/judgement.json -- per-criterion pass/fail with details

A MISSING verifier asset (rubrics / judge bundle) is a HARD error (exit 1) -- it
must never silently pass. A MISSING or unloadable agent document is a legitimate
score-0 (the agent produced no usable redline), not an error. The judge calls an
LLM panel via litellm; configure it with the standard provider keys (and
OPENAI_BASE_URL for an OpenAI-compatible gateway). JUDGE_PANEL overrides the
default 3-judge panel.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent  # /tests
VLIB = Path(os.environ.get("VERIFIER_LIB", str(HERE / "_verifier")))
sys.path.insert(0, str(VLIB))

RUBRICS = Path(os.environ.get("RUBRICS", str(HERE / "rubrics.json")))
CONTRACT = Path(os.environ.get("CONTRACT", "/app/contract.docx"))
REWARD_PATH = Path(os.environ.get("REWARD_PATH", "/logs/verifier/reward.txt"))
JUDGEMENT_PATH = Path(os.environ.get("JUDGEMENT_PATH", "/logs/verifier/judgement.json"))


def _hard_fail(msg: str) -> int:
    sys.stderr.write(f"VERIFIER ERROR: {msg}\n")
    return 1


def main() -> int:
    # Verifier assets MUST exist and import -- absence is a packaging error, never a pass.
    if not RUBRICS.exists():
        return _hard_fail(f"required asset missing: {RUBRICS}")
    try:
        from annotated_view import render_inline
        from judge import aggregate, call_judge, majority_vote, resolve_judges, validity_gate
        from judge_prompts import JUDGE_SYSTEM_PROMPT, build_user_prompt
    except Exception as exc:  # noqa: BLE001
        return _hard_fail(f"judge bundle failed to import from {VLIB}: {exc!r}")

    task = json.loads(RUBRICS.read_text())
    author = task["author"]
    rubrics = task["rubrics"]

    REWARD_PATH.parent.mkdir(parents=True, exist_ok=True)
    JUDGEMENT_PATH.parent.mkdir(parents=True, exist_ok=True)

    def emit(reward: float, judgement: dict) -> int:
        REWARD_PATH.write_text(f"{reward:.4f}\n")
        JUDGEMENT_PATH.write_text(json.dumps(judgement, indent=2))
        print(f"reward={reward:.4f}")
        return 0

    # Validity gate: a missing / unloadable / no-authored-trace doc is a graceful 0.
    ok, reason, _view = validity_gate(CONTRACT, author)
    if not ok:
        sys.stderr.write(f"VALIDITY GATE FAILED -> 0.0: {reason}\n")
        return emit(0.0, {"validity_gate": {"pass": False, "details": reason}})

    # Render the redline to the annotated judge view and grade via the panel.
    try:
        annotated = render_inline(CONTRACT)
        judges, mode = resolve_judges()
        user_prompt = build_user_prompt(task, annotated)
        per_judge, survivors, errors = [], [], []
        for j in judges:
            try:
                per_judge.append(call_judge(j, JUDGE_SYSTEM_PROMPT, user_prompt))
                survivors.append(j)
            except Exception as exc:  # noqa: BLE001 -- drop a failed judge, keep the panel
                errors.append((j, str(exc)[:200]))
        if not per_judge:
            return _hard_fail(f"all {len(judges)} judges failed: {errors}")
        response = majority_vote(per_judge) if mode == "panel" and len(per_judge) > 1 else per_judge[0]
        score = aggregate(response["verdicts"], rubrics)
    except Exception as exc:  # noqa: BLE001 -- never silently pass on a verifier bug
        return _hard_fail(f"grading failed: {type(exc).__name__}: {exc}")

    judgement = {
        p["rubric_id"]: {
            "pass": p["verdict"] == "PASS",
            "weight": p["weight"],
            "is_penalty": p["is_penalty"],
            "category": p.get("category"),
            "criteria": p["criteria"],
            "details": p.get("justification", ""),
        }
        for p in score["per_rubric"]
    }
    judgement["_summary"] = {
        "reward": round(score["weighted"], 4),
        "rubrics_passed": score["n_pass"],
        "rubrics_total": score["n_total"],
        "earned_weight": score["earned_weight"],
        "total_weight": score["total_weight"],
        "judges": survivors,
    }
    return emit(score["weighted"], judgement)


if __name__ == "__main__":
    sys.exit(main())
