#!/bin/bash
# Golden/oracle solution. Materializes the attorney gold redline as the agent
# output so the verifier scores ~1.0. Lives in solution/ (protected); never
# seeded into the agent environment. The ground-truth .docx is the attorney
# redline rendered with the task's author string, so it passes the validity gate
# and satisfies the rubrics directly.
set -euo pipefail

cp /solution/ground_truth.docx /app/contract.docx
